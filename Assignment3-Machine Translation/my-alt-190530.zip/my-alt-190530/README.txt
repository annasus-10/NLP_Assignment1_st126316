Myanmar ALT

					Masao Utiyama
					Thu May 30 00:00:00 JST 2019

* Introduction

This is the Myanmar ALT of the Asian Language Treebank (ALT) Corpus. English texts sampled from English Wikinews were available under a Creative Commons Attribution 2.5 License. 
Please refer to 
http://www2.nict.go.jp/astrec-att/member/mutiyama/ALT/index.html
for an introduction of the ALT project.

Myanmar ALT has been developed by NICT and UCSY. The license of Maynmar ALT is

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) License
https://creativecommons.org/licenses/by-nc-sa/4.0/


* Contents

- data : Myanmar ALT treebank 


* Disclaimer

[1] The content of the selected English Wikinews articles have been translated for this corpus. English texts sampled from English Wikinews were available under a Creative Commons Attribution 2.5 License. Users of the corpus are requested to take careful consideration when encountering any instances of defamation, discriminatory terms, or personal information that might be found within the corpus. Users of the corpus are advised to read Terms of Use in https://en.wikinews.org/wiki/Main_Page carefully to ensure proper usage.

[2] NICT bears no responsibility for the contents of the corpus and the lexicon and assumes no liability for any direct or indirect damage or loss whatsoever that may be incurred as a result of using the corpus or the lexicon.

[3] If any copyright infringement or other problems are found in the corpus or the lexicon, please contact us at alt-info[at]khn[dot]nict[dot]go[dot]jp. We will review the issue and undertake appropriate measures when needed.


